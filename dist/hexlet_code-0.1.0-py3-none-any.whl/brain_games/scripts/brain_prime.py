#!/usr/bin/env python
from brain_games.games.main_file import main_game


def main():
    print('Welcome to the Brain Games!')
    main_game('prime')


if __name__ == '__main__':
    main()
